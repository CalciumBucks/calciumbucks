# Login System
<h3>Usage</h3>
<p>You can implement this login system in your website.  There is a password reset and a regestration page.  Although not super secure, it is a good tool to use on GitHub Pages since it does not support PHP.  Use a free password hasher tool to hash your whole JavaScript file.</p>

<h3>Modifications</h3>
<p>You can change the password and usernames.  Just open the <q>script</q> folder and then open each JavaScript file and edit the passwords and usernames.</p>

<p>If you are having troubles contact me at <a href="mailto:info@michaelbateman.ca">info@michaelbateman.ca</a>.</p>